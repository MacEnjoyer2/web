import json
import os
import getpass
import keyring
import html
import readline
import re
import urllib.error
import urllib.parse
import urllib.request
from typing import Dict, Any, Optional
from cmd import Cmd

class DatabaseManager: 
    def __init__(self, db_file: str = 'database.json'):
        self.db_file = db_file
        self.data: Dict[str, Any] = {}
        self.load_data()
    
    def load_data(self) -> None:
        if os.path.exists(self.db_file):
            try:
                with open(self.db_file, 'r', encoding='utf-8') as f:
                    self.data = json.load(f)
                print("✓ Данные загружены")
            except json.JSONDecodeError as e:
                print(f"Ошибка чтения JSON ({self.db_file}): {e}")
                self.data = {}
            except OSError as e:
                print(f"Ошибка доступа к файлу ({self.db_file}): {e}")
                self.data = {}
        else:
            self.data = {}
    
    def save_data(self) -> None:
        try:
            with open(self.db_file, 'w', encoding='utf-8') as f:
                json.dump(self.data, f, ensure_ascii=False, indent=4)
            print("✓ JSON сохранен")
        except Exception as e:
            print(f"Ошибка сохранения: {e}")

class InputManager:
    @staticmethod
    def _remove_last_history_entry() -> None:
        """Не сохраняем ответы на внутренние запросы в историю команд."""
        try:
            current_length = readline.get_current_history_length()
            if current_length > 0:
                readline.remove_history_item(current_length - 1)
        except Exception:
            pass

    @staticmethod
    def regular_input(prompt: str = "") -> str:
        """Обычный ввод"""
        value = input(prompt).strip()
        InputManager._remove_last_history_entry()
        return value

    @staticmethod
    def raw_input(prompt: str = "") -> str:
        """Ввод без изменения строки"""
        value = input(prompt)
        InputManager._remove_last_history_entry()
        return value
    
    @staticmethod
    def password_input(prompt: str = "") -> str:
        """Скрытый ввод пароля"""
        return getpass.getpass(prompt)

class GoogleYandexMusicClient:
    def __init__(
        self,
        api_key_env: str = "GOOGLE_API_KEY",
        search_engine_env: str = "GOOGLE_SEARCH_ENGINE_ID",
        service: str = "Palitra",
        keyring_username: str = "google_api_key",
        search_engine_username: str = "google_search_engine_id"
    ):
        self.api_key_env = api_key_env
        self.search_engine_env = search_engine_env
        self.api_url = "https://www.googleapis.com/customsearch/v1"
        self.service = service
        self.keyring_username = keyring_username
        self.search_engine_username = search_engine_username

    def _get_secret(
        self,
        env_name: str,
        keyring_username: str,
        prompt_label: str,
        hidden: bool = True
    ) -> Optional[str]:
        env_value = os.getenv(env_name)
        if env_value:
            return env_value.strip()

        try:
            stored_value = keyring.get_password(self.service, keyring_username)
        except Exception as e:
            print(f"⚠️ Не удалось прочитать {prompt_label} из keyring: {e}")
            stored_value = None

        if stored_value:
            return stored_value.strip()

        print(f"🔐 {prompt_label} не найден. Введите его один раз, и он сохранится в системное хранилище.")
        if hidden:
            entered_value = getpass.getpass(f"{prompt_label}: ").strip()
        else:
            entered_value = input(f"{prompt_label}: ").strip()

        if not entered_value:
            return None

        try:
            keyring.set_password(self.service, keyring_username, entered_value)
            print(f"✅ {prompt_label} сохранён в системное хранилище.")
        except Exception as e:
            print(f"⚠️ Не удалось сохранить {prompt_label} в keyring: {e}")

        return entered_value

    def _get_api_key(self) -> Optional[str]:
        return self._get_secret(self.api_key_env, self.keyring_username, "Google API key")

    def _get_search_engine_id(self) -> Optional[str]:
        return self._get_secret(
            self.search_engine_env,
            self.search_engine_username,
            "Google Search Engine ID",
            hidden=False
        )

    @staticmethod
    def _parse_music_query(song_query: str) -> tuple[str, str]:
        parts = [part.strip() for part in song_query.split(" - ", 1)]
        if len(parts) == 2 and all(parts):
            return parts[0], parts[1]
        cleaned_query = song_query.strip()
        return cleaned_query, cleaned_query

    @staticmethod
    def _search_first_matching_link(items: list[Dict[str, Any]], pattern: str) -> Optional[str]:
        compiled = re.compile(pattern)
        for item in items:
            link = str(item.get("link", "")).strip()
            if compiled.search(link):
                return link
        return None

    @staticmethod
    def _extract_artist_url_from_items(items: list[Dict[str, Any]]) -> Optional[str]:
        for item in items:
            pagemap = item.get("pagemap", {})
            metatags = pagemap.get("metatags", [])
            for tag in metatags:
                musician_url = str(tag.get("music:musician", "")).strip()
                if re.search(r"music\.yandex\.(ru|com)/artist/\d+", musician_url):
                    return musician_url.replace("music.yandex.com", "music.yandex.ru")

            link = str(item.get("link", "")).strip()
            if re.search(r"music\.yandex\.(ru|com)/artist/\d+", link):
                return link.replace("music.yandex.com", "music.yandex.ru")

        return None

    def _google_search(self, api_key: str, search_engine_id: str, query: str) -> list[Dict[str, Any]]:
        params = urllib.parse.urlencode({
            "key": api_key,
            "cx": search_engine_id,
            "q": query,
            "num": 10,
        })
        request_url = f"{self.api_url}?{params}"

        request = urllib.request.Request(request_url, method="GET")
        with urllib.request.urlopen(request, timeout=60) as response:
            response_data = json.loads(response.read().decode("utf-8"))

        return response_data.get("items", [])

    @staticmethod
    def _normalize_track_url(track_url: str) -> str:
        return track_url.split("?", 1)[0].rstrip("/")

    @staticmethod
    def _normalize_artist_url(artist_url: str) -> str:
        return artist_url.split("?", 1)[0].rstrip("/")

    @staticmethod
    def _build_iframe_html(
        track_url: str,
        artist_url: str,
        track_title: str,
        artist_name: str
    ) -> Optional[str]:
        clean_track_url = GoogleYandexMusicClient._normalize_track_url(track_url)
        clean_artist_url = GoogleYandexMusicClient._normalize_artist_url(artist_url)

        parts = clean_track_url.split("/")
        if len(parts) < 7 or parts[-4] != "album" or parts[-2] != "track":
            return None

        album_id = parts[-3]
        track_id = parts[-1]
        iframe_url = f"https://music.yandex.ru/iframe/album/{album_id}/track/{track_id}"

        safe_track_title = html.escape(track_title.strip())
        safe_artist_name = html.escape(artist_name.strip())

        return (
            f'<iframe frameborder="0" allow="clipboard-write" '
            f'style="border:none;width:614px;height:244px;" width="614" height="244" '
            f'src="{html.escape(iframe_url, quote=True)}">'
            f'Слушайте <a href="{html.escape(clean_track_url, quote=True)}">'
            f'{safe_track_title}</a> — <a href="{html.escape(clean_artist_url, quote=True)}">'
            f'{safe_artist_name}</a> на Яндекс Музыке</iframe>'
        )

    def build_html_mus(self, song_query: str) -> Optional[str]:
        api_key = self._get_api_key()
        if not api_key:
            print("❌ Google API key не задан. Автопоиск HTML_MUS недоступен.")
            return None

        search_engine_id = self._get_search_engine_id()
        if not search_engine_id:
            print("❌ Google Search Engine ID не задан. Автопоиск HTML_MUS недоступен.")
            return None

        track_title, artist_name = self._parse_music_query(song_query)
        track_query = f'site:music.yandex.ru/album "{artist_name}" "{track_title}"'
        fallback_track_query = f"Яндекс музыка {artist_name} {track_title}"

        try:
            track_items = self._google_search(api_key, search_engine_id, track_query)
            fallback_items = self._google_search(api_key, search_engine_id, fallback_track_query)
        except urllib.error.HTTPError as e:
            error_body = e.read().decode("utf-8", errors="ignore")
            print(f"❌ Ошибка Google Search API: {e.code} {error_body}")
            return None
        except urllib.error.URLError as e:
            print(f"❌ Ошибка сети при обращении к Google Search API: {e}")
            return None
        except Exception as e:
            print(f"❌ Не удалось получить ответ Google Search API: {e}")
            return None

        track_url = self._search_first_matching_link(track_items, r"music\.yandex\.ru/album/\d+/track/\d+")
        if not track_url:
            track_url = self._search_first_matching_link(fallback_items, r"music\.yandex\.ru/album/\d+/track/\d+")
        if not track_url:
            print("❌ Google Search не нашёл полную ссылку трека Яндекс Музыки.")
            return None

        artist_url = self._extract_artist_url_from_items(track_items)
        if not artist_url:
            artist_url = self._extract_artist_url_from_items(fallback_items)
        if not artist_url:
            print("❌ Google Search не нашёл ссылку исполнителя Яндекс Музыки.")
            return None

        html_mus = self._build_iframe_html(track_url, artist_url, track_title, artist_name)
        if not html_mus:
            print("❌ Не удалось собрать iframe из найденных ссылок Яндекс Музыки.")
            return None

        return html_mus

class UserManager:
    def __init__(self, db: DatabaseManager, input_mgr: InputManager):
        self.db = db
        self.input_mgr = input_mgr
        self.ai_music = GoogleYandexMusicClient()
    
    def add_user(self) -> bool:
        user_id = self.input_mgr.regular_input("Введите номер пользователя: ")
        name = self.input_mgr.regular_input("Введите ФИО пользователя: ")
        music = self.input_mgr.regular_input("Введите музыку пользователя: ")
        
        user_data = {"NAME": name, "MUSIC": music}
        self.db.data[user_id] = user_data
        print(f"Пользователь {user_id} успешно добавлен/обновлен!")
        return True
    
    def remove_base(self) -> bool:
        access = Access("Palitra")
        if access.check_access():
            print("Доступ разрешен, начинаем удаление...")
            self.db.data.clear()
            print("База данных полностью очищена!")
            return True
        else:
            print("Вам тут не рады!")
            return False
    
    def show_all(self) -> None:
        print("\nТекущие данные:")
        print(json.dumps(self.db.data, ensure_ascii=False, indent=2))
    
    def clear_screen(self) -> None:
        os.system("cls" if os.name == "nt" else "clear")
    
    def add_user_info(self) -> bool:
        user_id = self.input_mgr.regular_input("Введите номер пользователя: ")
        
        if user_id not in self.db.data:
            print(f"Пользователь {user_id} не найден! Создаем нового.")
            self.db.data[user_id] = {}
        
        info = self.input_mgr.regular_input("Введите название нового поля: ").upper()
        if info == "HTML_MUS":
            print("Вставьте iframe одной строкой и нажмите Enter.")
            info_value = self.input_mgr.raw_input("HTML_MUS: ")
        else:
            info_value = self.input_mgr.regular_input("Введите значение поля: ")
        
        self.db.data[user_id][info] = info_value
        print(f"Поле '{info}: {info_value}' добавлено!")
        return True
    
    def remove_user_info(self) -> bool:
        user_id = self.input_mgr.regular_input("Введите номер пользователя: ")
        
        if user_id not in self.db.data:
            print(f"Error: пользователь {user_id} не найден!")
            return False
        
        search_term = self.input_mgr.regular_input("Введите данные для поиска (ключ или значение): ")
        user_dict = self.db.data[user_id]
        found = False
        
        if search_term in user_dict:
            del user_dict[search_term]
            print(f"Ключ '{search_term}' удален!")
            found = True
        else:
            for key, value in list(user_dict.items()):
                if str(value).strip().lower() == search_term.lower():
                    del user_dict[key]
                    print(f"Значение '{search_term}' удалено из ключа '{key}'!")
                    found = True
                    break
        
        if not found:
            print("Error: данные не найдены!")
        
        return found
    
    def find_user(self) -> None:
        query = self.input_mgr.regular_input("Поиск: ")
        found_users = []
        
        for user_id, user_data in self.db.data.items():
            if isinstance(user_data, dict):
                for key, value in user_data.items():
                    value_str = str(value)
                    if query.lower() in value_str.lower():
                        print(f"  🎯 [{user_id}] {key}: {value_str}")
                        print(f"     └─ найдено: {json.dumps(self.db.data[user_id],ensure_ascii=False,indent=4)}")
                        found_users.append((user_id, user_data))
                        break
        
        if not found_users:
            print("❌ Ничего не найдено")
    
    def make_site_from_html_mus(self) -> bool:
        user_id = self.input_mgr.regular_input("Введите номер пользователя: ")
        if user_id not in self.db.data or not isinstance(self.db.data[user_id], dict):
            print(f"❌ Пользователь {user_id} не найден!")
            return False

        user_data = self.db.data[user_id]
        html_mus = user_data.get("HTML_MUS")
        if not html_mus:
            music_query = str(user_data.get("MUSIC", "")).strip()
            if not music_query:
                print(f"❌ У пользователя {user_id} нет поля HTML_MUS и MUSIC.")
                return False

            print("ℹ️ HTML_MUS не найден. Пробуем получить iframe через Google Search API...")
            html_mus = self.ai_music.build_html_mus(music_query)
            if not html_mus:
                print("❌ Не удалось автоматически получить HTML_MUS.")
                return False

            user_data["HTML_MUS"] = html_mus
            print("✅ HTML_MUS автоматически найден и сохранён в базу.")

        pages_dir = "html_pages"
        os.makedirs(pages_dir, exist_ok=True)

        raw_html = str(html_mus)
        page_content = f"""<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>HTML_MUS пользователя {user_id}</title>
  <style>
    body {{
      font-family: Arial, sans-serif;
      background: #f5f5f5;
      margin: 0;
      padding: 24px;
    }}
    h1 {{
      margin-top: 0;
      font-size: 20px;
    }}
  </style>
</head>
<body>
  <h1>Песня: {user_data["NAME"]}</h1>
  {raw_html}
</body>
</html>
"""
        file_path = os.path.join(pages_dir, f"{user_data['NAME']}.html")
        try:
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(page_content)
        except OSError as e:
            print(f"❌ Ошибка создания файла: {e}")
            return False

        print(f"✅ Страница создана: {file_path}")
        return True

class Access:
    def __init__(self, service: str = "Palitra"):
        self.service = service
        self.username = "admin"
        self.password = keyring.get_password(self.service, self.username)
        
        if not self.password:
            print("Пароль не найден. Устанавливаем...")
            self.set_credentials()
    
    def set_credentials(self) -> None:
        print(f"Сохранение пароля для {self.service}:{self.username}")
        while True:
            password = getpass.getpass("Введите пароль: ")
            confirm = getpass.getpass("Подтвердите пароль: ")
            
            if password == confirm:
                keyring.set_password(self.service, self.username, password)
                self.password = password
                print("✅ Пароль сохранён в системное хранилище!")
                return
            
            print("❌ Пароли не совпадают!")
    
    def check_access(self) -> bool:
        input_user = input("Логин: ").strip()
        input_pass = getpass.getpass("Пароль: ")
        
        if input_user == self.username and input_pass == self.password:
            print("✅ Добро пожаловать!")
            return True
        else:
            print("❌ Неверные данные!")
            return False

class PalitraCmd(Cmd):
    """PALITRA - интерактивная консоль управления базой данных"""
    
    prompt = 'PALITRA >>> '
    intro = "🔓 PALITRA запущена! Введите 'help' для списка команд."
    valid_commands = {"addU", "rmBase", "addUInf", "all", "clear", "rmUInf", "findU", "mksite", "help", "end", "quit", "EOF"}
    
    def __init__(self):
        super().__init__()
        self.db = DatabaseManager()
        self.input_mgr = InputManager()
        self.user_mgr = UserManager(self.db, self.input_mgr)
        self.doc_header = "Доступные команды (введите help <команда>):"
        self.histfile = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".cmd_history")
        self._setup_history()

    def _setup_history(self) -> None:
        try:
            readline.set_history_length(1000)
            if os.path.exists(self.histfile):
                readline.read_history_file(self.histfile)
        except Exception:
            pass

    def _save_command(self, line: str) -> None:
        stripped_line = line.strip()
        command = stripped_line.split(maxsplit=1)[0] if stripped_line else ""
        if command not in self.valid_commands:
            return

        try:
            current_length = readline.get_current_history_length()
            if current_length == 0 or readline.get_history_item(current_length) != stripped_line:
                readline.add_history(stripped_line)
            readline.write_history_file(self.histfile)
        except Exception:
            pass

    def precmd(self, line):
        self._save_command(line)
        return super().precmd(line)
    
    def do_addU(self, arg):
        """addU - добавить/обновить пользователя (ФИО, музыка)"""
        if self.user_mgr.add_user():
            self.db.save_data()
    
    def do_rmBase(self, arg):
        """rmBase - полностью очистить базу данных (требует пароль)"""
        if self.user_mgr.remove_base():
            self.db.save_data()
    
    def do_addUInf(self, arg):
        """addUInf - добавить произвольное поле пользователю"""
        if self.user_mgr.add_user_info():
            self.db.save_data()
    
    def do_all(self, arg):
        """all - показать все данные"""
        self.user_mgr.show_all()
    
    def do_clear(self, arg):
        """clear - очистить экран"""
        self.user_mgr.clear_screen()
    
    def do_rmUInf(self, arg):
        """rmUInf - удалить поле у пользователя"""
        if self.user_mgr.remove_user_info():
            self.db.save_data()
    
    def do_findU(self, arg):
        """findU - поиск по пользователям"""
        self.user_mgr.find_user()

    def do_mksite(self, arg):
        """mksite - создать HTML-страницу из поля HTML_MUS пользователя"""
        if self.user_mgr.make_site_from_html_mus():
            self.db.save_data()
    
    def do_help(self, arg):
        """help - показать справку"""
        if arg:
            super().do_help(arg)
        else:
            print("\n📋 Основные команды:")
            print("- addU     - добавить пользователя")
            print("- addUInf  - добавить поле пользователю")
            print("- rmUInf   - удалить поле")
            print("- findU    - поиск")
            print("- mksite   - создать HTML-страницу из HTML_MUS")
            print("- all      - показать все")
            print("- rmBase   - очистить базу (пароль)")
            print("- clear    - очистить экран")
            print("- end/quit/EOF - выход")
    
    def do_end(self, arg):
        """end - завершить работу"""
        print("👋 До свидания!")
        return True
    
    def do_quit(self, arg):
        """quit - завершить работу"""
        print("👋 До свидания!")
        return True
    
    def do_EOF(self, line):
        """EOF (Ctrl+D) - выход"""
        print("\n👋 До свидания!")
        return True
    
    def emptyline(self):
        """Пустая строка - ничего не делать"""
        pass
    
    def default(self, line):
        """Неизвестная команда"""
        print(f"❌ Неизвестная команда: '{line}'")
        print("Введите 'help' для списка команд")

def main():
    access = Access("Palitra")
    if access.check_access():
        print("\n🔓 Доступ получен!")
        app = PalitraCmd()
        try:
            app.cmdloop(app.intro)
        except KeyboardInterrupt:
            print("\n\n👋 До свидания!")
    else:
        print("🚫 Доступ запрещён!")

if __name__ == "__main__":
    main()