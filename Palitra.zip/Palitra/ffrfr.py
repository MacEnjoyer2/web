nums = [2, 5, 1, 8, 3, 6]
result = 0

for n in nums:
    if n > result:
        result += n
    else:
        result -= 1

print(result)
